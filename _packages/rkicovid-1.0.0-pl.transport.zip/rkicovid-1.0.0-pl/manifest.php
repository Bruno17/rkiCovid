<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4b2667415d56fb8c9d417a52038f97fc',
      'native_key' => 'rkicovid',
      'filename' => 'modNamespace/d018f10784190fe5a7e215eb044750e2.vehicle',
      'namespace' => 'rkicovid',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4cc915dddaefff8339de95475c836e11',
      'native_key' => NULL,
      'filename' => 'modCategory/7d83a56a9e3359e54bedaa2de676b6b5.vehicle',
      'namespace' => 'rkicovid',
    ),
  ),
);