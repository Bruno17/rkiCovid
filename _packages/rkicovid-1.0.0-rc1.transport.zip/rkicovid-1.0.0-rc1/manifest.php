<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4b7faaac2349387650d9604a166fa01f',
      'native_key' => 'rkicovid',
      'filename' => 'modNamespace/a2cbafb9f25e7ab2e0b11d0eefdc0948.vehicle',
      'namespace' => 'rkicovid',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'becb8e684bf212abf1793c63d2b85bf1',
      'native_key' => NULL,
      'filename' => 'modCategory/93471042caf35f19ba73727a1a569fbb.vehicle',
      'namespace' => 'rkicovid',
    ),
  ),
);